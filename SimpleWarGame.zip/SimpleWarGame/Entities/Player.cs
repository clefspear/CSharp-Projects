using System;
using System.Collections.Generic;
using System.Text;

namespace SimpleWarGame
{
    /// <summary>
    /// The Player class.  High Health and Armor. Uses various kinds of Ammo selected by the player.
    /// </summary>
    public class Player : Entity
    {
        /// <summary> 
        /// Player Constructor. Takes no arguments. 
        /// Initalizies an Player to default values. 
        /// </summary> 
        public Player()
        {
            this.MaxHealth = 150;
            this.Health = MaxHealth;
            this.Armor = 10;
            this.name = "Player";
            this.Weapon = null;

        }
        /// <summary> 
        /// Allows the player to select which weapon they want to use.  /// </summary> 
        /// <param name="type">The weapon they would like to use. Check the weaponType  enum for possible options.</param> 
        public void SelectWeapon(weaponType type)
        {
            switch (type)
            {
                case weaponType.explosive:
                    this.Weapon = new ExplodeAmmo();
                    break;
                case weaponType.piercing:
                    this.Weapon = new PiercingAmmo();
                    break;
            }
        }
        /// <summary> 
        /// Allows the player to attack an enemy target 
        /// </summary> 
        public override void Attack(Entity target)
        {
            Random random = new Random();
            target.Defend(random.Next(10) + this.Weapon.AttackMod, random.Next(this.Weapon.damage.min, this.Weapon.damage.max));
        }
        /// <summary> 
        /// Allows the player to defend an enemy attack 
        /// </summary> 
        public override void Defend(int hit, int damage)
        {
            if (hit > this.Armor)
            {
                this.Health -= damage;
            }
            else
                Console.WriteLine(this.Name + " missed its target!");
        }
        /// <summary> 
        /// Heals the player to maximum health. 
        /// </summary> 
        public void Heal()
        {
            this.Health = this.MaxHealth;
        }
    }
}
