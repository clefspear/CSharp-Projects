using System;
using System.Collections.Generic;
using System.Text;

namespace SimpleWarGame
{
    /// <summary>
    /// The EnemyTruck class.  Low Health and Armor. Uses Missle Ammo.
    /// </summary>
    public class EnemyTruck : Entity
    {
        /// <summary> 
        /// EnemyTruck Constructor. Takes no arguments.  /// Initalizies an EnemyTruck to default values.  /// </summary> 
        public EnemyTruck()
        {


            this.MaxHealth = 25;
            this.Health = MaxHealth;
            this.Armor = 5;
            this.name = "Tank";
            this.Weapon = new MissleAmmo();
        }
        /// <summary> 
        /// Allows EnemyTruck to attack a player 
        /// </summary> 
        public override void Attack(Entity target)
        {
            Random random = new Random();
            target.Defend(random.Next(10) + this.Weapon.AttackMod, random.Next(this.Weapon.damage.min, this.Weapon.damage.max));
        }
        /// <summary> 
        /// Allows EnemyTruck to defend against a player attack  /// </summary> 
        public override void Defend(int hit, int damage)
        {
            if (hit > this.Armor)
            {
                this.Health -= damage;
            }
            else
                Console.WriteLine(this.Name + " missed the target!");
        }
    }
}  
