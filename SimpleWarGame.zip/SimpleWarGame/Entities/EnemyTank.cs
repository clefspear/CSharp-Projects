using System;
using System.Collections.Generic;
using System.Text;

namespace SimpleWarGame
{
    /// <summary> 
    /// The EnemyTank class. High health and Armor. Uses Slug Ammo.  /// </summary> 
    public class EnemyTank : Entity
    {
        /// <summary> 
        /// EnemyTank Constructor. Takes no arguments.  /// Initalizies an EnemyTank to default values.  /// </summary> 
        public EnemyTank()
        {
            this.MaxHealth = 80;
            this.Health = MaxHealth;
            this.Armor = 10;
            this.name = "Tank";
            this.Weapon = new SlugAmmo();
            //break; 
        }
        /// <summary> 
        /// Allows EnemyTank to attack a player 
        /// </summary> 
        public override void Attack(Entity target)
        {

            Random random = new Random();
            target.Defend(random.Next(10) + this.Weapon.AttackMod, random.Next(this.Weapon.damage.min, this.Weapon.damage.max));
        }
        /// <summary> 
        /// Allows EnemyTank to defend against a player attack  /// </summary> 
        public override void Defend(int hit, int damage)
        {
            if (hit > this.Armor)
            {
                this.Health -= damage;
            }
            else
                Console.WriteLine(this.Name + " missed its target!");
        }
    }
}
