using System;
using System.Collections.Generic;
using System.Text;

namespace SimpleWarGame
{
    /// <summary> 
    /// ExplodeAmmo is a type of Weapon.  
    /// Has no bonus to attack. 
    /// Inpercise (wide range) but high damage. 
    /// </summary> 
    public class ExplodeAmmo : Weapon
    {
        /// <summary> 
        /// ExplodeAmmo Constructor. Takes no arguments.  /// Sets default values. 
        /// </summary> 
        public ExplodeAmmo()
        {
            this.Name = "Explosive";
            this.damage.min = 5;
            this.damage.max = 20;
            this.AttackMod = 0;
        }
    }
}
