using System;
using System.Collections.Generic;
using System.Text;

namespace SimpleWarGame
{
    /// <summary>
    /// Abstract base class for all weapons in the game.
    /// </summary>
    public abstract class Weapon : GameObject
    {
        /// <summary> 
        /// Protected attackModifier property for weapon  /// </summary> 
        protected int attackModifier;
        /// <summary> 
        /// damage property for weapon 
        /// </summary> 
        public Damage damage;
        /// <summary> 
        /// Damage struct 
        /// </summary> 
        public struct Damage
        {
            /// <summary> 
            /// min property for Damage 
            /// </summary> 
            public int min;
            /// <summary> 
            /// max property for Damage 
            /// </summary> 
            public int max;
        }
        /// <summary> 
        /// AttackMod property for weapon 
        /// </summary> 
        public int AttackMod
        {
            get { return attackModifier; }
            set { attackModifier = value; }
        }
    }

}
