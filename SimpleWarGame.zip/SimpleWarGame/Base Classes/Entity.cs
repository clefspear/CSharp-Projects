using System;
using System.Collections.Generic;
using System.Text;

namespace SimpleWarGame
{
    /// <summary>
    /// Abstract Base class for all character agents (AKA Entities).
    /// Every Entity has Health, Armor, and MaxHealth properties.
    /// Every Entity has Attack and Defend methods.
    /// </summary>
    public abstract class Entity : GameObject
    {
        /// <summary>
        /// Protected health property for entity
        /// </summary>
        protected int health;
        /// <summary>
        /// Protected armor property for entity
        /// </summary>
        protected int armor;
        /// <summary>
        /// Protected maxHealth property for entity
        /// </summary>
        protected int maxHealth;
        /// <summary>
        /// Weapon property for entity
        /// </summary>
        public Weapon Weapon;
        /// <summary>
        /// Health property for entity
        /// </summary>
        public int Health
        {
            get
            {
                return health;
            }
            set
            {
                if (value > MaxHealth)
                    health = MaxHealth;
                else if (value < 0)
                    health = 0;
                else
                    health = value;
            }

        }
        /// <summary>
        /// Armor property for entity
        /// </summary>
        protected int Armor
        {
            get { return armor; }
            set
            {
                if (value > 25)
                    armor = 25;
                else
                    armor = value;
            }
        }
        /// <summary>
        /// MaxHealth property for entity
        /// </summary>
        protected int MaxHealth
        {
            get { return maxHealth; }
            set { maxHealth = value; }
        }
        /// <summary>
        /// Abstract attack method for entity
        /// </summary>
        public abstract void Attack(Entity target);
        /// <summary>
        /// Abstract defend method for entity
        /// </summary>
        public abstract void Defend(int hit, int damage);
    }
}